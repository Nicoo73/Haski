module GameState
  ( GameState(..)
  , Direction(..)
  , Bullet(..)
  , initialState
  , playerSize
  , basePlayerSpeed
  , addKey
  , removeKey
  ) where

import Enemy
import Wave
import Item (Item) -- Importamos el módulo Item

-------------------------------------------------------------
-- DIRECCIONES
-------------------------------------------------------------

data Direction = DUp | DDown | DLeft | DRight
  deriving (Eq, Show)

-------------------------------------------------------------
-- PROYECTIL
-------------------------------------------------------------

data Bullet = Bullet
  { bulletPos :: (Float, Float)
  , bulletDir :: Direction
  , bulletSpeed :: Float
  } deriving (Show)  

-------------------------------------------------------------
-- GAMESTATE
-------------------------------------------------------------

data GameState = GameState
  { playerPos    :: (Float, Float)
  , playerDir    :: Direction 
  , keysDown     :: [Direction]
  , animTime     :: Float
  , windowSize   :: (Int, Int)
  
  -- Entidades
  , enemies      :: [Enemy]
  , bullets      :: [Bullet]
  , items        :: [Item]       -- NUEVO: Lista de items en el suelo
  
  -- Estado del Juego
  , wave         :: Wave
  , waveCount    :: Int
  , playerHP     :: Int          -- NUEVO: Vida del jugador
  , currentSpeed :: Float        -- NUEVO: Velocidad actual (modificable por items)
  , score        :: Int          -- NUEVO: Puntuación (opcional, para el item de bonus)
  } deriving (Show)

-------------------------------------------------------------
-- CONSTANTES
-------------------------------------------------------------

playerSize :: Float
playerSize = 16.0

basePlayerSpeed :: Float
basePlayerSpeed = 200.0

-------------------------------------------------------------
-- ESTADO INICIAL
-------------------------------------------------------------

initialState :: GameState
initialState = GameState
  { playerPos    = (0, 0)
  , playerDir    = DUp
  , keysDown     = []
  , animTime     = 0.0
  , windowSize   = (480, 360)
  , enemies      = []
  , bullets      = []
  , items        = []            -- Inicialmente vacía
  , wave         = initialWave
  , waveCount    = 1
  , playerHP     = 100           -- Vida inicial
  , currentSpeed = basePlayerSpeed
  , score        = 0
  }

-------------------------------------------------------------
-- FUNCIONES PARA GESTIONAR INPUT (keys)
-------------------------------------------------------------

addKey :: Direction -> GameState -> GameState
addKey dir gs =
  gs { keysDown =
        if dir `elem` keysDown gs
        then keysDown gs
        else dir : keysDown gs }

removeKey :: Direction -> GameState -> GameState
removeKey dir gs =
  gs { keysDown = filter (/= dir) (keysDown gs) }